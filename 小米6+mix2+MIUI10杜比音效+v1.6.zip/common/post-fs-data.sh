 #!/system/bin/sh


mount -o rw,remount / 2>/dev/null
mount -o rw,remount /data 2>/dev/null
mount -o rw,remount /system 2>/dev/null
mount -o rw,remount /vendor 2>/dev/null


if [ -e /system_root/init.rc ]; then
  root=/system_root
elif [ -e /system/init.rc ]; then
  root=/system
else
  root=""
fi


(
  dtsdir=/data/misc/dts
  if [ ! -d "$dtsdir" ]; then
    mkdir -p $dtsdir
    chmod 0775 $dtsdir
    chown 1013.1005 $dtsdir
    chcon u:object_r:dts_data_file:s0 $dtsdir
  elif [ "$(ls -A /data/misc/dts 2>/dev/null)" ]; then
    for dtsfile in $dtsdir/*; do
      chmod 0644 $dtsfile
      chown 1041.1005 $dtsfile
      chcon -R u:object_r:dts_data_file:s0 $dtsdir
    done
  fi
)&


(
  audio0=/vendor/etc/audio
  audio1=$root/system/vendor/etc/audio
  etc0=$root/system/etc
  etc1=$root/system/vendor/etc
  etc2=/vendor/etc
  policy16=audio_policy_configuration.xml
  policy24=audio_policy_configuration_24bit.xml
  policy32=audio_policy_configuration_32bit.xml
  policya2dp=a2dp_audio_policy_configuration.xml
  policydrc=audio_policy_volumes_drc.xml
  policysub=r_submix_audio_policy_configuration.xml
  policyusb=usb_audio_policy_configuration.xml
  policyvol=default_volumes_table.xml
  if [ ! -d /odm ]; then
    for audiodir in $audio0 $audio1; do
      if [ -e "$audiodir/$policy16" ]; then
        for audiopolicy in $audiodir/$policy16 $audiodir/$policy24 $audiodir/$policy32 $audiodir/$policya2dp $audiodir/$policydrc $audiodir/$policysub $audiodir/$policyusb $audiodir/$policyvol; do
          if [ -e "$audiopolicy" ]; then
            mkdir -p /odm/etc
            chmod 0755 /odm /odm/etc
            chown 1000.1000 /odm /odm/etc
            chcon -R u:object_r:system_file:s0 /odm
            ln -sf $audiopolicy /odm/etc/
          fi
        done
      else
        for etcdir in $etc0 $etc1 $etc2; do
          if [ -e "$etcdir/$policy16" ]; then
            for audiopolicy in $etcdir/$policy16 $etcdir/$policy24 $etcdir/$policy32 $etcdir/$policya2dp $etcdir/$policydrc $etcdir/$policysub $etcdir/$policyusb $etcdir/$policyvol; do
              if [ -e "$audiopolicy" ]; then
                mkdir -p /odm/etc
                chmod 0755 /odm /odm/etc
                chown 1000.1000 /odm /odm/etc
                chcon -R u:object_r:system_file:s0 /odm
                ln -sf $audiopolicy /odm/etc/
              fi
            done
          fi
        done
      fi
    done
  fi
  mount -o ro,remount /system 2>/dev/null
  mount -o ro,remount /vendor 2>/dev/null
  exit 0
)&

setenforce 0
