#!/system/bin/sh


mount -o rw,remount / 2>/dev/null
mount -o rw,remount /system 2>/dev/null


if [ -e /system_root/init.rc ]; then
  root=/system_root
elif [ -e /system/init.rc ]; then
  root=/system
else
  root=""
fi


(
  supolicy --live "create dolby_prop dts_data_file hal_audio_default hal_broadcastradio_hwservice" "allow hal_audio_default servicemanager binder *" "allow { audioserver priv_app servicemanager } { device dts_data_file hal_audio_default system_data_file } dir *" "allow { audioserver hal_audio_default mediaserver priv_app servicemanager system_server } { audioserver audioserver_tmpfs dolby_prop dts_data_file hal_audio_default mediaserver_tmpfs proc_interrupts proc_modules sysfs unlabeled } file *" "allow audioserver hal_broadcastradio_hwservice hwservice_manager *" "allow { hal_audio_default servicemanager } hal_audio_default process *" "allow hal_audio_default audioserver_service service_manager *" "allow priv_app property_socket sock_file *" "allow priv_app init unix_stream_socket *" 2>/dev/null
)&


(
  tinymix=$root/system/bin/tinymix
  if [ -e "$tinymix" ]; then
    $tinymix 'DS2 OnOff' '1' 2>/dev/null
    $tinymix 'HiFi Function' 'On' 2>/dev/null
  fi
)&


(
  sleep 10
  mount -o ro,remount /system 2>/dev/null
  exit 0
)&
